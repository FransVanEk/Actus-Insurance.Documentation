```

BenchmarkDotNet v0.15.8, Windows 11 (10.0.26200.8037/25H2/2025Update/HudsonValley2)
AMD Ryzen 7 3800X 3.90GHz, 1 CPU, 16 logical and 8 physical cores
.NET SDK 9.0.311
  [Host]   : .NET 9.0.14 (9.0.14, 9.0.1426.11910), X64 RyuJIT x86-64-v3
  ShortRun : .NET 9.0.14 (9.0.14, 9.0.1426.11910), X64 RyuJIT x86-64-v3

Job=ShortRun  IterationCount=3  LaunchCount=1  
WarmupCount=3  

```
| Method                                                                              | BatchSize | Mean            | Error           | StdDev          | Ratio | RatioSD | ns/c/s     | Rank | Gen0         | Gen1         | Allocated      | Alloc Ratio |
|------------------------------------------------------------------------------------ |---------- |----------------:|----------------:|----------------:|------:|--------:|-----------:|-----:|-------------:|-------------:|---------------:|------------:|
| &#39;CPU: sequential Schedule + Apply (50-yr monthly, 602 events/contract)&#39;             | 1         |        148.4 μs |        135.1 μs |         7.41 μs |  1.00 |    0.06 |  148360.83 |    1 |      27.5879 |       5.3711 |      227.09 KB |        1.00 |
| &#39;GPU: compute path — On-ramp + H2D + kernel (no D2H, sink on device) ← fair vs CPU&#39; | 1         |      1,204.8 μs |        309.4 μs |        16.96 μs |  8.13 |    0.36 | 1204844.01 |    2 |      25.3906 |       3.9063 |      209.95 KB |        0.92 |
| &#39;GPU: full path — On-ramp + H2D + kernel + sink (zero-alloc D2H)&#39;                   | 1         |      1,235.7 μs |        154.8 μs |         8.48 μs |  8.34 |    0.36 | 1235697.43 |    2 |      25.3906 |       3.9063 |      210.07 KB |        0.93 |
|                                                                                     |           |                 |                 |                 |       |         |            |      |              |              |                |             |
| &#39;GPU: compute path — On-ramp + H2D + kernel (no D2H, sink on device) ← fair vs CPU&#39; | 10000     |    892,041.7 μs |  1,650,298.7 μs |    90,458.44 μs |  0.66 |    0.06 |   89204.17 |    1 |  174000.0000 |   32000.0000 |  2093828.58 KB |        0.92 |
| &#39;GPU: full path — On-ramp + H2D + kernel + sink (zero-alloc D2H)&#39;                   | 10000     |  1,041,204.4 μs |    387,471.7 μs |    21,238.63 μs |  0.77 |    0.04 |  104120.44 |    1 |  174000.0000 |   32000.0000 |  2093828.66 KB |        0.92 |
| &#39;CPU: sequential Schedule + Apply (50-yr monthly, 602 events/contract)&#39;             | 10000     |  1,355,411.1 μs |  1,277,398.0 μs |    70,018.50 μs |  1.00 |    0.06 |  135541.11 |    2 |  277000.0000 |   58000.0000 |   2270937.5 KB |        1.00 |
|                                                                                     |           |                 |                 |                 |       |         |            |      |              |              |                |             |
| &#39;GPU: compute path — On-ramp + H2D + kernel (no D2H, sink on device) ← fair vs CPU&#39; | 100000    |  8,323,049.0 μs |  1,275,193.7 μs |    69,897.67 μs |  0.60 |    0.01 |   83230.49 |    1 | 1746000.0000 |  290000.0000 |  20938281.7 KB |        0.92 |
| &#39;GPU: full path — On-ramp + H2D + kernel + sink (zero-alloc D2H)&#39;                   | 100000    |  9,361,436.5 μs |  2,054,597.7 μs |   112,619.43 μs |  0.68 |    0.01 |   93614.37 |    1 | 1746000.0000 |  290000.0000 | 20938281.78 KB |        0.92 |
| &#39;CPU: sequential Schedule + Apply (50-yr monthly, 602 events/contract)&#39;             | 100000    | 13,863,761.1 μs |  3,336,625.4 μs |   182,891.70 μs |  1.00 |    0.02 |  138637.61 |    2 | 2777000.0000 |  558000.0000 |    22709375 KB |        1.00 |
|                                                                                     |           |                 |                 |                 |       |         |            |      |              |              |                |             |
| &#39;GPU: full path — On-ramp + H2D + kernel + sink (zero-alloc D2H)&#39;                   | 200000    | 20,046,417.3 μs |    496,864.5 μs |    27,234.82 μs |  0.70 |    0.02 |  100232.09 |    1 | 3493000.0000 |  582000.0000 | 41876563.03 KB |        0.92 |
| &#39;GPU: compute path — On-ramp + H2D + kernel (no D2H, sink on device) ← fair vs CPU&#39; | 200000    | 20,270,397.2 μs | 42,627,290.7 μs | 2,336,545.65 μs |  0.71 |    0.07 |  101351.99 |    1 | 3493000.0000 |  582000.0000 | 41876562.95 KB |        0.92 |
| &#39;CPU: sequential Schedule + Apply (50-yr monthly, 602 events/contract)&#39;             | 200000    | 28,651,382.1 μs | 15,276,272.9 μs |   837,344.07 μs |  1.00 |    0.04 |  143256.91 |    2 | 5555000.0000 | 1113000.0000 |    45418750 KB |        1.00 |
